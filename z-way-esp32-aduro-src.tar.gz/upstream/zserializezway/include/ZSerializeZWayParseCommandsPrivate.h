//
//  ZSerializeZWayParseCommandsPrivate.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 08.10.2024.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_zway_parse_commands_private_h
#define zserialize_zway_parse_commands_private_h

#include "ZSerializeCommonPrivate.h"
#include "ZSerializeCommonParsePrivate.h"
#include "ZSerializeDownloadPrivate.h"
#include "ZByteOperationsPrivate.h"
#include "ZStreamPrivate.h"
#include "ZWayLib.h"

#define ZSERIALIZE_ZWAY_PARSE_DONGLE "zway"
#define ZSERIALIZE_ZWAY_PARSE_ZWAVE "ZWave"
#define ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_INSTANCES "instances"
#define ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_CCS "commandClasses"

#define ZSERIALIZE_ZWAY_PARSE_DONGLE_REQUEST ZSERIALIZE_COMMON_PARSE_DONGLE_REQUEST(ZSERIALIZE_ZWAY_PARSE_ZWAVE)
#define ZSERIALIZE_ZWAY_PARSE_DONGLE_RESPONSE ZSERIALIZE_COMMON_PARSE_DONGLE_RESPONSE(ZSERIALIZE_ZWAY_PARSE_DONGLE)

#define ZSERIALIZE_ZWAY_PARSE_REG_INSTANCE_DATA_SET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_PATH(ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_INSTANCES) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_SET "$"
#define ZSERIALIZE_ZWAY_PARSE_REG_INSTANCE_DATA_GET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_PATH(ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_INSTANCES) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_GET "$"

#define ZSERIALIZE_ZWAY_PARSE_REG_CC_FUNCTION "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CC_PATH(ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_INSTANCES, ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_CCS) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_FUNCTION "$"
#define ZSERIALIZE_ZWAY_PARSE_REG_CC_DATA_SET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CC_PATH(ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_INSTANCES, ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_CCS) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_SET "$"
#define ZSERIALIZE_ZWAY_PARSE_REG_CC_DATA_GET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CC_PATH(ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_INSTANCES, ZSERIALIZE_ZWAY_PARSE_REG_PREFIX_CCS) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_GET "$"

#define ZSERIALIZE_ZWAY_PARSE_REG_ZWAVE_DATA ZSERIALIZE_COMMON_PARSE_REG_DATA(ZSERIALIZE_ZWAY_PARSE_ZWAVE, ZSERIALIZE_ZWAY_PARSE_DONGLE)
#define ZSERIALIZE_ZWAY_PARSE_REG_ZWAVE_RUN ZSERIALIZE_COMMON_PARSE_REG_RUN(ZSERIALIZE_ZWAY_PARSE_ZWAVE, ZSERIALIZE_ZWAY_PARSE_DONGLE)
#define ZSERIALIZE_ZWAY_PARSE_REG_ZWAVE_INSPECT_QUEUE ZSERIALIZE_COMMON_PARSE_REG_INSPECT_QUEUE(ZSERIALIZE_ZWAY_PARSE_ZWAVE, ZSERIALIZE_ZWAY_PARSE_DONGLE)
#define ZSERIALIZE_ZWAY_PARSE_REG_ZWAVE_FIRMWARE_UPDATE ZSERIALIZE_COMMON_PARSE_REG_FIRMWARE_UPDATE(ZSERIALIZE_ZWAY_PARSE_ZWAVE, ZSERIALIZE_ZWAY_PARSE_DONGLE)

ZWEXPORT_PRIVATE ZWError _zserialize_zway_parse(const ZWay zway, const ZWSTR in, const _ZStreamHttpWrite_t *const stream, void *const ctx_stream, const ZWBOOL gzip);

static inline void _zserialize_zway_parse_free(_ZSerializeCommonCtx_t *const ctx)
{
    return _zserialize_common_free(ctx);
}

static inline ZWBOOL _zserialize_zway_command_contains(const ZWCSTR cmd)
{
    static const ZWCHAR cmd_parser[] = "/" ZSERIALIZE_ZWAY_PARSE_ZWAVE;
    return _zserialize_common_parse_command_contains(cmd, cmd_parser, Z_STATIC_STRLEN(cmd_parser));
}

ZWEXPORT_PRIVATE ZWError _zserialize_zway_common_tree_parse_to_string(const ZWay zway, time_t timestamp, const ZWBOOL is_string, _ZByteData_t *const data);
ZWEXPORT_PRIVATE ZWError _zserialize_zway_inspect_queue_parse_to_string(const ZWay zway, const ZWBOOL is_string, _ZByteData_t *const data);
ZWEXPORT_PRIVATE ZWError _zserialize_zway_parse_command_parse_to_string(const ZWay zway, ZWSTR input, const ZWBOOL is_string, _ZByteData_t *const data);

ZWEXPORT_PRIVATE ZWBOOL _zserialize_zway_is_command_upgrade(ZWCSTR cmd);
ZWEXPORT_PRIVATE ZWError _zserialize_zway_upgrade_extract_node_id(const ZWay zway, const ZWSTR command, ZWNODE *const node_id);

static inline ZWay __zserialize_zway_parse_get_root_object(_ZSerializeCommonCtx_t *const ctx)
{
    return (ZWay)_zserialize_common_get_root_object(ctx);
}

#endif // zserialize_zway_parse_commands_private_h
