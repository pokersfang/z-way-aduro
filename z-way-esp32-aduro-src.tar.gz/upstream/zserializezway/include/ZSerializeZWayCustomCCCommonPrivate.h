//
//  ZSerializeZWayCustomCCCommonPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_zway_custom_cccommon_private_h
#define zserialize_zway_custom_cccommon_private_h

#ifdef __cplusplus
extern "C" {
#endif

// Run Command Class Interview.
//
// @JSName: Interview
//
// @param: zway
// Z-Way object instance
//
// @param: device_id
// Node Id
//
// @param: instance_id
// Instance Id
//
// @param: cc_id
// Command Class Id
//
static inline ZWError _zway_cc_common_interview(const ZWay zway, ZWNODE device_id, ZWBYTE instance_id, ZWBYTE cc_id)
{
    return zway_command_interview(zway, device_id, instance_id, cc_id);
}

#ifdef __cplusplus
}
#endif

#endif // zserialize_zway_custom_cccommon_private_h
