//
//  ZSerializeZWayCustomWithReturnPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_zway_custom_with_return_private_h
#define zserialize_zway_custom_with_return_private_h

#ifdef __cplusplus
extern "C" {
#endif

// Request Is idle
//
// @JSName: isIdle
//
// @param: zway
// ZWay object instance
//
ZWError _zway_with_return_is_idle(ZWay zway, _ZSerializeCommonCtx_t *ctx);

#ifdef __cplusplus
}
#endif

#endif // zserialize_zway_custom_with_return_private_h
