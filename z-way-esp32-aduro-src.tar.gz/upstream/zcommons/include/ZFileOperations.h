//
//  ZFileOperations.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zfile_operations_h
#define zfile_operations_h

#include "ZPlatform.h"
#include "ZLog.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(__ESP32__)
ZWError zfile_fs_init(const ZWCSTR label, const ZWCSTR label_dynamic);
#else
static inline ZWError zfile_fs_init(const ZWCSTR UNUSED(label), const ZWCSTR UNUSED(label_dynamic))
{
    return NoError;
}
#endif

#ifdef __cplusplus
}
#endif

#endif //zfile_operations_h
