//
//  ZDataDefs.h
//  z-commons
//
//  Created by Alex Skalozub on 11/03/14.
//
//  Copyright (c) 2014 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//

#ifndef zdata_defs_h
#define zdata_defs_h

struct _ZDataCallbackListEntry;
typedef struct _ZDataCallbackListEntry *ZDataCallbackListEntry;

struct _ZDataCallbackList;
typedef struct _ZDataCallbackList *ZDataCallbackList;

#endif
