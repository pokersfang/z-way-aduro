//
//  ZLogPrivate.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 11/03/14.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zlog_private_h
#define zlog_private_h

#include "ZPlatform.h"
#include "ZLog.h"
#include "ZDataPrivate.h"
#include "ZMutexPrivate.h"

#if defined(__MACH__)
#include <asl.h>
#endif

struct _ZWLog
{
    FILE *file;
    _ZMutexCtx_t *ctx_mutex;
    ZWLogLevel level;
    ZWBOOL syslog;
#if defined(__MACH__)
    aslclient asl;
#endif
};

ZWEXPORT_PRIVATE void zlog_write_v(ZWLog log, ZWCSTR source, ZWLogLevel level, PRINTF_FORMAT_STRING ZWCSTR message, va_list arg);
ZWEXPORT_PRIVATE ZWError _zlog_change_level(const ZWLog log, const ZWLogLevel level);
static inline ZWLogLevel _zlog_get_log_level(const ZWLog log)
{
    return log->level;
};
ZWEXPORT_PRIVATE ZWError _zlog_error_too_short(const struct _ZDataRootObject *const root, const ZWCSTR where, const size_t expected, const size_t actual);

#ifdef DEBUG
ZWEXPORT_PRIVATE void _zlog_debug_log_error(const struct _ZDataRootObject *const root, const ZWError err, const ZWError opt, const ZWCSTR func, const ZWCSTR file, const int line);
#define ZLOG_ERR_EXT(root, r) _zlog_debug_log_error(root, r, NoError, #r, __FILE__, __LINE__)
#define ZLOG_ERR_OPT_EXT(root, r) _zlog_debug_log_error(root, r, NotSupported, #r, __FILE__, __LINE__)
#else
ZWEXPORT_PRIVATE void _zlog_debug_log_error(const struct _ZDataRootObject *const root, const ZWError err, const ZWError opt, const ZWCSTR func);
#define ZLOG_ERR_EXT(root, r) _zlog_debug_log_error(root, r, NoError, #r)
#define ZLOG_ERR_OPT_EXT(root, r) _zlog_debug_log_error(root, r, NotSupported, #r)
#endif // DEBUG

#define ZLOG_CHECK_SIZE(root, where, actual, expected) if ((size_t)(expected) > (size_t)(actual)) \
{ \
    return _zlog_error_too_short(root, where, expected, actual); \
}

#endif
