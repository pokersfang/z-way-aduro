//
//  ZDataList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/29/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zdata_list_h
#define zdata_list_h

#include "ZDataDefs.h"
#include "ZData.h"

#ifdef __cplusplus
extern "C" {
#endif

void _zdata_free_children(ZDataHolder const data);
void _zdata_append_child(ZDataHolder const parent, ZDataHolder const data);
void _zdata_remove_child(ZDataHolder const parent, ZDataHolder const data);

#ifdef __cplusplus
}
#endif

#endif
