//
//  ZParseArgumentsPrivate.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 08.10.2024.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zparse_arguments_private_h
#define zparse_arguments_private_h

#include "ZPlatform.h"
#include "ZLog.h"
#include "ZDataPrivate.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef ZWBYTE _zparse_arguments_type_t;
typedef enum _ZParseArgumentsType_e
{
    _ZParseArgumentsTypeNull = 0,
    _ZParseArgumentsTypeBoolean,
    _ZParseArgumentsTypeString,
    _ZParseArgumentsTypeStringXml,
    _ZParseArgumentsTypeByte,
    _ZParseArgumentsTypeWord,
    _ZParseArgumentsTypeDword,
    _ZParseArgumentsTypeDword64,
    _ZParseArgumentsTypeInteger,
    _ZParseArgumentsTypeInteger64,
    _ZParseArgumentsTypeFloat,
    _ZParseArgumentsTypeBinaryArray,
    _ZParseArgumentsTypeBinaryArrayXml,
    _ZParseArgumentsTypeBinaryArray8,
    _ZParseArgumentsTypeBinaryArray16,
    _ZParseArgumentsTypeWordArray,
    _ZParseArgumentsTypeDwordArray,
    _ZParseArgumentsTypeIntegerArray,
    _ZParseArgumentsTypeInteger64Array,
    _ZParseArgumentsTypeFloatArray,
    _ZParseArgumentsTypeStringArray,
} _ZParseArgumentsType_t;

typedef union _ZParseArgumentsValue_s
{
    ZWLONGINT64 int64Value;
    ZWDWORD64 dwordValue64;
    ZWDWORD dwordValue;
    ZWWORD wordValue;
    ZWBYTE byteValue;
    int intValue;
    float floatValue;
    ZWSTR strValue;
    ZWBOOL boolValue;
    int *intArrayValue;
    ZWLONGINT64 *int64ArrayValue;
    ZWBYTE *binaryArrayValue;
    ZWWORD *wordArrayValue;
    ZWDWORD *dwordArrayValue;
    float *floatArrayValue;
    ZWSTR *strArrayValue;
    void *ptr;
} _ZParseArgumentsValue_t;

typedef struct _ZParseArgumentsContainer_s
{
    _ZParseArgumentsValue_t value;
    size_t length;
    _ZParseArgumentsType_t target_type : 5;
    ZWBOOL allocated;
} _ZParseArgumentsContainer_t;

typedef struct _ZParseArgumentsResult_s
{
    _ZParseArgumentsContainer_t container;
    ZWCSTR nextParams;
} _ZParseArgumentsResult_t;

ZWEXPORT_PRIVATE ZWBOOL _zparse_arguments_is_type_array_dimensionless(const _ZParseArgumentsType_t type);
ZWEXPORT_PRIVATE ZWBOOL _zparse_arguments_is_type_array_dimensionless_size(const _ZParseArgumentsType_t type);
ZWEXPORT_PRIVATE ZWBOOL _zparse_arguments_set_type_array(_ZParseArgumentsContainer_t *const container, const _ZParseArgumentsType_t type, const ZWDWORD value);

ZWEXPORT_PRIVATE ZWCSTR _zparse_arguments_skip_spaces(const ZWCSTR params);
ZWEXPORT_PRIVATE ZWError _zparse_arguments(const ZWLog log, ZWCSTR params, _ZParseArgumentsResult_t *const result, const _ZParseArgumentsType_t target);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_detecting(ZWCSTR params, _ZParseArgumentsResult_t *const result);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_packs(const ZWLog log, ZWCSTR params, _ZParseArgumentsContainer_t *const container, _zparse_arguments_type_t const *target, const size_t n);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_set_value(const ZWLog log, ZDataValue *const value, _ZParseArgumentsResult_t *const res);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_set(const ZWLog log, const ZDataHolder data, _ZParseArgumentsResult_t *const res);
ZWEXPORT_PRIVATE void _zparse_arguments_free(_ZParseArgumentsContainer_t *const result);
ZWEXPORT_PRIVATE void _zparse_arguments_free_containers(_ZParseArgumentsContainer_t *const container, const size_t n);
ZWEXPORT_PRIVATE void _zparse_arguments_set_default_containers(_ZParseArgumentsContainer_t *const container, const size_t n);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_number_dec_target(const ZWLog log, const ZWCSTR params, const _ZParseArgumentsType_t target, const ZWBOOL without_end, ZWLONGINT64 *const p_value);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_number_udec(const ZWLog log, const ZWCSTR input, const ZWDWORD64 value_min, const ZWDWORD64 value_max, const ZWBOOL without_end, ZWDWORD64 *const p_value);
ZWEXPORT_PRIVATE ZWError _zparse_arguments_number_dec(const ZWLog log, const ZWCSTR input, const ZWLONGINT64 value_min, const ZWLONGINT64 value_max, const ZWBOOL without_end, ZWLONGINT64 *const p_value);

#ifdef __cplusplus
}
#endif

#endif // zparse_arguments_private_h
