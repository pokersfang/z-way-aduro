//
//  ZMutexPrivate.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/7/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zmutex_private_h
#define zmutex_private_h

#include "ZPlatform.h"
#include "ZLog.h"

typedef struct _ZMutexCtx_s
{
#if defined(__FREERTOS__)
    StaticSemaphore_t xMutexBuffer;
    SemaphoreHandle_t xSemaphore;
#else
    pthread_mutex_t mutex;
    pthread_mutexattr_t mutex_attr;
#endif
    ZWBOOL recursive;
} _ZMutexCtx_t;

ZWEXPORT_PRIVATE _ZMutexCtx_t *_zmutex_create_common(const ZWBOOL recursive);
static inline _ZMutexCtx_t *_zmutex_create(void)
{
    return _zmutex_create_common(FALSE);
}
static inline _ZMutexCtx_t *_zmutex_create_recursive(void)
{
    return _zmutex_create_common(TRUE);
}
ZWEXPORT_PRIVATE void _zmutex_destroy(_ZMutexCtx_t *const ctx);
ZWEXPORT_PRIVATE void _zmutex_enter(_ZMutexCtx_t *const ctx, const ZWLog log);
ZWEXPORT_PRIVATE void _zmutex_exit(_ZMutexCtx_t *const ctx, const ZWLog log);

#endif // zmutex_private_h
