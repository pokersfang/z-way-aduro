//
//  ZErrorsPrivate.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/6/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zerrors_private_h
#define zerrors_private_h

#include "ZPlatform.h"

#ifdef __cplusplus
extern "C" {
#endif

ZWEXPORT_PRIVATE ZWSTR _zerrors_sys_last_err_string_get(void);
ZWEXPORT_PRIVATE void _zerrors_sys_last_err_string_free(const ZWSTR e);
ZWEXPORT_PRIVATE void _zerrors_backtrace_print(void);

#ifdef __cplusplus
}
#endif

#endif // zerrors_private_h
