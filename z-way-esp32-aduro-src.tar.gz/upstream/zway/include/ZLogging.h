//
//  ZLogging.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 11/03/14.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_logging_h
#define zway_logging_h

#include "ZLog.h"
#include "ZDefsPublic.h"
#include "ZWayLib.h"

#define zway_log(zway, level, message, ...) zlog_write_root(ZDataRoot(zway), level, message, ##__VA_ARGS__)
static inline void zway_dump(const ZWay zway, const ZWLogLevel level, const ZWCSTR prefix, const size_t length, const ZWBYTE *const buffer)
{
    return zlog_dump_root(ZDataRoot(zway), level, prefix, length, buffer);
}
static inline void zway_log_error(const ZWay zway, const ZWLogLevel level, const ZWCSTR message, const ZWError error)
{
    return zlog_error_root(ZDataRoot(zway), level, message, error);
}
#endif
