# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
if(NOT ZWAY_CMAKE_PYTHON_EXECUTABLE)
  find_package("Python3" REQUIRED COMPONENTS Interpreter)
  set(ZWAY_CMAKE_PYTHON_EXECUTABLE
      "${Python3_EXECUTABLE}"
      CACHE FILEPATH "")
endif()

if(DEFINED ENV{IDF_PATH})
  option(ZWAY_CMAKE_BUILDS_SHARED "" OFF)
else()
  option(CMAKE_POSITION_INDEPENDENT_CODE "" ON)
  option(ZWAY_CMAKE_BUILDS_SHARED "" ON)
endif()

set(ZWAY_CMAKE_ROOT
    "${CMAKE_CURRENT_LIST_DIR}/.."
    CACHE FILEPATH "")

if(${CMAKE_BUILD_TYPE} MATCHES "Debug")
  option(ZWAY_CMAKE_TESTS_CXX "" ON)
else()
  option(ZWAY_CMAKE_TESTS_CXX "" OFF)
endif()

set(ZWAY_CMAKE_SECURITY_LIB
    "zs2"
    CACHE STRING "")

set(ZWAY_CMAKE_PROJECT_LIST
    ""
    CACHE STRING "")

set(ZWAY_CMAKE_PREBUILD_LIBS
    ""
    CACHE FILEPATH "")
set(ZWAY_CMAKE_CACHE_ESPRESSIF
    ""
    CACHE FILEPATH "")

if(APPLE
   AND NOT CMAKE_OSX_ARCHITECTURES
   AND CMAKE_SYSTEM_PROCESSOR)
  set(CMAKE_OSX_ARCHITECTURES
      ${CMAKE_SYSTEM_PROCESSOR}
      CACHE STRING "" FORCE)
endif()

include("${ZWAY_CMAKE_ROOT}/cmake/function/generate_option.cmake")
