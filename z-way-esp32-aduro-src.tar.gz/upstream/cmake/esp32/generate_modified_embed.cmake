# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
cmake_minimum_required(VERSION 3.13...3.27.9)

set(__last_modified_embed_files)

foreach(file ${EMBED_FILES})
  get_filename_component(__name ${file} NAME)
  string(TIMESTAMP __output_variable "%a, %d %b %Y %H:%M:%S GMT" UTC)
  string(MAKE_C_IDENTIFIER "${__name}" __name)
  set(__last_modified_embed_files "${__last_modified_embed_files}const char g_${__name}_last_modified[] = \"${__output_variable}\";\n")
  unset(__name)
  unset(__output_variable)
endforeach()

execute_process(COMMAND ${CMAKE_COMMAND} -E echo "${__last_modified_embed_files}")
