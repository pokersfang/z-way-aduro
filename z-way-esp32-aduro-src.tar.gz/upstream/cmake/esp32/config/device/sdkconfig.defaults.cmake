# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
if(NOT EXISTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.defaults.${ZWAY_CMAKE_ESP32_DEVICE}")
  message(FATAL_ERROR "The \"${ZWAY_CMAKE_ESP32_DEVICE}\" not supported!!!")
endif()

list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.defaults.${ZWAY_CMAKE_ESP32_DEVICE}")
