# How to add your chip/device/device variant

## Adding support for a new chip
In the ./sdkconfig.defaults.cmake file, you need to add support for this chip - search for **IDF_TARGET**.
Then add the sdkconfig file for that chip to the ./target and ./ram files.

## Adding support for a new device
In the ./sdkconfig.defaults.cmake file, you need to add support for this device - search for **ZWAY_CMAKE_ESP32_DEVICE**.
Then in the ./device folder add the sdkconfig file for this device
If the chip's flash memory is 4MB, then take this into account in the ./sdkconfig.flash.cmake file - look for **CONFIG_ESPTOOLPY_FLASHSIZE_4MB**

## Adding support for a new device variant
Let's look at the z-way-esp32 project as an example.


In the z-way-esp32/main/cmake/interface/CMakeLists.txt file, add processing for your custom settings – search for **ZWAY_CMAKE_ESP32_DEVICE_VARIANT**. This allows you to change variant-specific settings such as UART pins.
- **ZWAY_ESP32_ZWAVE_UART1_TX** - TX pin of ZWAVE controller
- **ZWAY_ESP32_ZWAVE_UART1_RX** - RX pin of ZWAVE controller
- **ZWAY_ESP32_ON_ETHERNET** - includes ETHERNET support
- **ZWAY_ESP32_ON_WIFI** - includes Wifi support

The remaining defines are specific - see the source files and z-way-esp32/main/cmake/interface/CMakeLists.txt


To include it in the general assembly, you need to add your settings **ZWAY_CMAKE_ESP32_DEVICE_VARIANT** and **ZWAY_CMAKE_ESP32_DEVICE** (if adding a new device), **IDF_TARGET** (if adding a new chip) to the z-way-esp32/builder/esp32.json file.

As an example, we add a new chip "chip_xxx" and device "device_xxx" and device variant "device_variant_xxx"
This will be added in "esp32.json"
```
    {
        "name": "chip_xxx",
        "devices":
        [
            {
                "name": "device_xxx",
                "devices_variant":
                [
                    {
                        "name": "device_variant_xxx",
                        "with_zwave": true
                    },
                    {
                        "name": "device_variant_xxx",
                        "with_zwave": true,
                        "with_zmatter_bridge": true
                    }
                ]
            }
        ]
    }
```

Where **with_zwave** includes **Z-Wave** support in the build, **with_zmatter_bridge** includes **Matter Bridge** support in the build