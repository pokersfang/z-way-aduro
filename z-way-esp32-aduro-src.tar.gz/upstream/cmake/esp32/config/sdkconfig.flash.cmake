# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_BINARY_DIR}/sdkconfig_flash/sdkconfig.flash.defaults")

set(__sdkconfig_flash)
set(__partitions_littlefs_csv)

set(__app_data_size "1024")
set(__nvs_data_size "24")
set(__phy_data_size "4")

set(__sdkconfig_flash "${__sdkconfig_flash}# Setting up the file system\n")
set(__sdkconfig_flash "${__sdkconfig_flash}CONFIG_PARTITION_TABLE_CUSTOM_FILENAME=\"${CMAKE_BINARY_DIR}/sdkconfig_flash/partitions_littlefs.csv\"\n")

set(__partitions_littlefs_csv "${__partitions_littlefs_csv}# Name,   Type, SubType, Offset,  Size, Flags\n")
set(__partitions_littlefs_csv "${__partitions_littlefs_csv}# Note: if you have increased the bootloader size, make sure to update the offsets to avoid overlap\n")
set(__partitions_littlefs_csv "${__partitions_littlefs_csv}nvs,      data, nvs,     ,  ${__nvs_data_size}k,\n")
set(__partitions_littlefs_csv "${__partitions_littlefs_csv}phy_init, data, phy,     ,  ${__phy_data_size}k,\n")

math(EXPR ZWAY_CMAKE_ESP32_OFFSET_FOR_APP "0x1000 + ${__nvs_data_size} * 1024 + ${__phy_data_size} * 1024")

if(NOT "ZWAY_CMAKE_SUPPORT_ZWAVE" IN_LIST ZWAY_CMAKE_SUPPORTS_MODULE)
  message(FATAL_ERROR "At least one of them must be displayed: ZWAY_CMAKE_SUPPORT_ZWAVE")
endif()

if("ZWAY_CMAKE_SUPPORT_ZWAVE" IN_LIST ZWAY_CMAKE_SUPPORTS_MODULE)
  math(EXPR __app_data_size "2048 + ${__app_data_size}")
endif()

if("ZWAY_CMAKE_SUPPORT_ZMATTER_BRIDGE" IN_LIST ZWAY_CMAKE_SUPPORTS_MODULE)
  math(EXPR __app_data_size "1024 + ${__app_data_size}")
endif()

set(__partitions_littlefs_csv "${__partitions_littlefs_csv}factory,  app,  factory, , ${__app_data_size}k,\n")

set(__sdkconfig_flash "${__sdkconfig_flash}CONFIG_ESPTOOLPY_FLASHSIZE_${ZWAY_CMAKE_ESP32_DEVICE_FLASHSIZE}MB=y\n")
set(__sdkconfig_flash "${__sdkconfig_flash}CONFIG_ESPTOOLPY_FLASHSIZE=\"${ZWAY_CMAKE_ESP32_DEVICE_FLASHSIZE}MB\"\n")

file(WRITE "${CMAKE_BINARY_DIR}/sdkconfig_flash/sdkconfig.flash.defaults" "${__sdkconfig_flash}")
file(WRITE "${CMAKE_BINARY_DIR}/sdkconfig_flash/partitions_littlefs.csv" "${__partitions_littlefs_csv}")

unset(__sdkconfig_flash)
unset(__partitions_littlefs_csv)
unset(__app_data_size)
unset(__nvs_data_size)
unset(__phy_data_size)
