# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
if(${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "dev-esp32")
  return()
endif()

list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.defaults")

if(NOT EXISTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.defaults.${IDF_TARGET}")
  message(FATAL_ERROR "The \"${IDF_TARGET}\" not supported!!!")
endif()

list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.defaults.${IDF_TARGET}")
