# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
include($ENV{IDF_PATH}/tools/cmake/project.cmake)

set(SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.defaults")

include("${CMAKE_CURRENT_LIST_DIR}/target/sdkconfig.defaults.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/ram/sdkconfig.defaults.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/sdkconfig.flash.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/device/sdkconfig.defaults.cmake")

if(CMAKE_BUILD_TYPE)
  if(${CMAKE_BUILD_TYPE} STREQUAL "Release")
    list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_LIST_DIR}/sdkconfig.release")
  endif()
endif()

if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/cfg/sdkconfig.defaults")
  list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_SOURCE_DIR}/cfg/sdkconfig.defaults")
endif()

if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/cfg/sdkconfig.defaults.${ZWAY_CMAKE_ESP32_DEVICE}")
  list(APPEND SDKCONFIG_DEFAULTS "${CMAKE_CURRENT_SOURCE_DIR}/cfg/sdkconfig.defaults.${ZWAY_CMAKE_ESP32_DEVICE}")
endif()
