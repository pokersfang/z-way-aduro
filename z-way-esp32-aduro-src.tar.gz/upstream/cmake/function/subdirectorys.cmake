# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
include("${CMAKE_CURRENT_LIST_DIR}/../option.cmake")

function(__zway_cmake_function_subdirectorys_resolve_path_ext subdirectory output prebuild_libs)
  if(subdirectory STREQUAL "zcommons")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zcommons"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-commons"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zway")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zway"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-way"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zbee")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zbee"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-bee"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zwaycli")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zwaycli"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-way-cli"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zs2")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zs2"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-s2"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "ts2")
    option(TS2_LOG_DEBUG "" ON)
    option(TS2_DEBUG_FSM "" ON)
    option(TS2_DEBUG_TRANSPORT "" ON)
    option(TS2_DEBUG_CRYPTO_ENGINE "" ON)
    option(TS2_DEBUG_INCLUSION "" ON)
    option(TS2_CONTROLLER_SUPPORT "" ON)
    option(TS2_SOFTWARE_DEFINED_CRYPTO "" ON)
    option(TS2_FSM_MAIN_LOGGER "" ON)
    option(TS2_NO_DEFAULT_ROUTINES_PUBLIC_KEY "" OFF)
    option(TS2_NO_DEFAULT_ROUTINES_MEMORY "" ON)
    option(TS2_NO_DEFAULT_ROUTINES_MILLIS "" ON)
    option(TS2_NO_DEFAULT_ROUTINES_LOGGING "" ON)
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/ts2"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/TrustyS2"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zwaysrv")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zwaysrv"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-way-srv"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zserializecommon")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zserializecommon"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-serialize/z-serialize-common"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zserializezway")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zserializezway"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-serialize/z-serialize-zway"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zserializezbee")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zserializezbee"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-serialize/z-serialize-zbee"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zmatterbridge")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zmatterbridge"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-matter-bridge"
          PARENT_SCOPE)
    endif()
  elseif(subdirectory STREQUAL "zmatterbridgezway")
    if(prebuild_libs)
      set(${output}
          "${prebuild_libs}/zmatterbridgezway"
          PARENT_SCOPE)
    else()
      set(${output}
          "${ZWAY_CMAKE_ROOT}/z-matter-bridge/zway"
          PARENT_SCOPE)
    endif()
  else()
    message(FATAL_ERROR "'${subdirectory}' - not supported!!!")
  endif()
endfunction()

function(__zway_cmake_function_subdirectorys_resolve_path subdirectory output)
  if(ZWAY_CMAKE_PREBUILD_LIBS)
    __zway_cmake_function_subdirectorys_resolve_path_ext(${subdirectory} __output ${ZWAY_CMAKE_PREBUILD_LIBS})
  else()
    __zway_cmake_function_subdirectorys_resolve_path_ext(${subdirectory} __output OFF)
  endif()
  set(${output}
      ${__output}
      PARENT_SCOPE)
endfunction()
