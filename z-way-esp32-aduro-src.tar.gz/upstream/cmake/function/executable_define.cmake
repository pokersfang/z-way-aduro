# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
include("${CMAKE_CURRENT_LIST_DIR}/../option.cmake")
function(__zway_cmake_function_executable_define_inner target option name)
  if(option IN_LIST ZWAY_CMAKE_SUPPORTS_MODULE)
    target_compile_definitions(${target} PRIVATE "${name}=1")
  else()
    target_compile_definitions(${target} PRIVATE "${name}=0")
  endif()
endfunction()

function(__zway_cmake_function_executable_define target)
  __zway_cmake_function_executable_define_inner("${target}" "ZWAY_CMAKE_SUPPORT_ZWAVE" "ZWAY_SUPPORT_ZWAVE")
  __zway_cmake_function_executable_define_inner("${target}" "ZWAY_CMAKE_SUPPORT_ZBEE" "ZWAY_SUPPORT_ZBEE")
  __zway_cmake_function_executable_define_inner("${target}" "ZWAY_CMAKE_SUPPORT_ZMATTER_BRIDGE" "ZWAY_SUPPORT_ZMATTER_BRIDGE")
endfunction()
