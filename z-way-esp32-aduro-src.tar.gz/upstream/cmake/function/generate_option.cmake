# ***************************************************************************
# SPDX-License-Identifier: LicenseRef-TridentMSLA
# SPDX-FileCopyrightText: 2026 Trident IoT, LLC <https://www.tridentiot.com>
# ***************************************************************************
function(__zway_cmake_function_generate_option)
  if(DEFINED ENV{IDF_PATH} AND NOT SDKCONFIG_DEFAULTS)
    list(APPEND COMPONENTS "main")
    list(APPEND COMPONENTS "esp_psram")

    if(NOT ZWAY_CMAKE_ESP32_DEVICE)
      if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/CMakeLists.dev.cmake")
        include("${CMAKE_CURRENT_SOURCE_DIR}/CMakeLists.dev.cmake")
        if(ZWAY_CMAKE_ESP32_DEVICE)
          message(STATUS "ZWAY_CMAKE_ESP32_DEVICE is set, guessed '${ZWAY_CMAKE_ESP32_DEVICE}' from '${CMAKE_CURRENT_SOURCE_DIR}/CMakeLists.dev.cmake'")
          set(ZWAY_CMAKE_ESP32_DEVICE
              "${ZWAY_CMAKE_ESP32_DEVICE}"
              CACHE STRING "")
        endif()
      endif()
    endif()

    if(NOT ZWAY_CMAKE_ESP32_DEVICE AND NOT IDF_TARGET)
      set(IDF_TARGET
          "esp32s3"
          CACHE STRING "")
      set("ZWAY_CMAKE_ESP32_DEVICE" "dev-esp32s3")

      message(STATUS "ZWAY_CMAKE_ESP32_DEVICE and IDF_TARGET not set, using default: '${ZWAY_CMAKE_ESP32_DEVICE}' and '${IDF_TARGET}'")
    endif()

    if(NOT ZWAY_CMAKE_ESP32_DEVICE)
      if(${IDF_TARGET} STREQUAL "esp32")
        set(ZWAY_CMAKE_ESP32_DEVICE
            "prod-esp32N8R2"
            CACHE STRING "")
      elseif(${IDF_TARGET} STREQUAL "esp32s3")
        set(ZWAY_CMAKE_ESP32_DEVICE
            "dev-esp32s3"
            CACHE STRING "")
      elseif(${IDF_TARGET} STREQUAL "esp32p4")
        set(ZWAY_CMAKE_ESP32_DEVICE
            "dev-esp32p4"
            CACHE STRING "")
      else()
        message(FATAL_ERROR "The \"${IDF_TARGET}\" not supported!!!")
      endif()

      message(STATUS "ZWAY_CMAKE_ESP32_DEVICE not set, using default: '${ZWAY_CMAKE_ESP32_DEVICE}' for target '${IDF_TARGET}'")
    endif()

    set(__idf_target)
    if(${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "dev-esp32"
       OR ${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "dev-wrov1"
       OR ${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "prod-esp32N8R2"
       OR ${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "prod-wb-mgu")
      set(__idf_target "esp32")
    elseif(${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "dev-esp32s3")
      set(__idf_target "esp32s3")
    elseif(${ZWAY_CMAKE_ESP32_DEVICE} STREQUAL "dev-esp32p4")
      set(__idf_target "esp32p4")
    else()
      message(FATAL_ERROR "The \"${ZWAY_CMAKE_ESP32_DEVICE}\" not supported!!!")
    endif()

    if(NOT IDF_TARGET)
      set(IDF_TARGET
          ${__idf_target}
          CACHE STRING "")
      message(STATUS "IDF_TARGET not set, using target: '${IDF_TARGET}' for '${ZWAY_CMAKE_ESP32_DEVICE}'")
    elseif(NOT (${IDF_TARGET} STREQUAL ${__idf_target}))
      message(FATAL_ERROR "'${IDF_TARGET}' is not suitable for '${ZWAY_CMAKE_ESP32_DEVICE}'")
    endif()
    unset(__idf_target)

    set(__devices_4mb "dev-esp32" "dev-wrov1" "prod-wb-mgu")
    if(ZWAY_CMAKE_ESP32_DEVICE IN_LIST __devices_4mb)
      set(ZWAY_CMAKE_ESP32_DEVICE_FLASHSIZE
          "4"
          CACHE STRING "" FORCE)
    else()
      set(ZWAY_CMAKE_ESP32_DEVICE_FLASHSIZE
          "8"
          CACHE STRING "" FORCE)
    endif()
    unset(__devices_4mb)
  endif()

  set(options)
  set(oneValueArgs)
  set(multiValueArgs PROJECTS SUPPORTS)
  cmake_parse_arguments(__zway_cmake_function_generate_option "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

  if(__zway_cmake_function_generate_option_UNPARSED_ARGUMENTS)
    message(FATAL_ERROR "__zway_cmake_function_generate_option Wrong syntax. There are unparsed arguments: ${__zway_cmake_function_generate_option_UNPARSED_ARGUMENTS}")
  endif()

  if(__zway_cmake_function_generate_option_KEYWORDS_MISSING_VALUES)
    message(FATAL_ERROR "__zway_cmake_function_generate_option Wrong syntax. There are keywords missing values: ${__zway_cmake_function_generate_option_KEYWORDS_MISSING_VALUES}")
  endif()

  if(NOT __zway_cmake_function_generate_option_PROJECTS)
    message(FATAL_ERROR "__zway_cmake_function_generate_option: There is a missing argument 'PROJECTS'")
  endif()

  if(NOT __zway_cmake_function_generate_option_SUPPORTS)
    message(FATAL_ERROR "__zway_cmake_function_generate_option Wrong syntax: There is a missing argument 'SUPPORTS'")
  endif()
  set(supports_all "ZWAY_CMAKE_SUPPORT_ZMATTER_BRIDGE" "ZWAY_CMAKE_SUPPORT_ZBEE" "ZWAY_CMAKE_SUPPORT_ZWAVE")
  foreach(support ${__zway_cmake_function_generate_option_SUPPORTS})
    if(NOT support IN_LIST supports_all)
      message(FATAL_ERROR "__zway_cmake_function_generate_option not support var: '${support}'")
    endif()
  endforeach()

  set(serialize OFF)
  set(cli OFF)
  set(zwave OFF)
  set(zbee OFF)
  set(matter_bridge OFF)
  foreach(project ${__zway_cmake_function_generate_option_PROJECTS})
    if(${project} STREQUAL "z-way-srv-test")
      set(serialize ON)
      set(zwave ON)
    elseif(${project} STREQUAL "z-way-test")
      set(cli ON)
      set(zwave ON)
    elseif(${project} STREQUAL "z-bee-test")
      set(zbee ON)
    elseif(${project} STREQUAL "z-way-esp32")
      set(serialize ON)
      set(matter_bridge ON)
      set(zwave ON)
      set(cli ON)
    elseif(${project} STREQUAL "z-tests-auto")
      set(serialize ON)
      set(zwave ON)
      set(zbee ON)
    else()
      message(FATAL_ERROR "Project ${project} is not supported!!!")
    endif()
  endforeach()

  set(supports)
  foreach(support ${__zway_cmake_function_generate_option_SUPPORTS})
    if(support STREQUAL "ZWAY_CMAKE_SUPPORT_ZMATTER_BRIDGE" AND APPLE)
      continue()
    endif()

    if(support STREQUAL "ZWAY_CMAKE_SUPPORT_ZBEE" AND ESP_PLATFORM)
      continue()
    endif()

    if(DEFINED ${support})
      if(NOT ${support})
        continue()
      endif()
    endif()

    list(APPEND supports ${support})
  endforeach()
  if(supports)
    list(REMOVE_DUPLICATES supports)
  endif()
  list(SORT supports)
  if(DEFINED ENV{IDF_PATH} AND NOT SDKCONFIG_DEFAULTS)
    set(__device_support)
    set(__device_support_max)
    if(ZWAY_CMAKE_ESP32_DEVICE_FLASHSIZE EQUAL 4)
      list(APPEND __device_support "ZWAY_CMAKE_SUPPORT_ZWAVE")
    else()
      list(APPEND __device_support "ZWAY_CMAKE_SUPPORT_ZWAVE ZWAY_CMAKE_SUPPORT_ZMATTER_BRIDGE")
      list(APPEND __device_support "ZWAY_CMAKE_SUPPORT_ZWAVE")
    endif()
    foreach(device_support ${__device_support})
      string(REPLACE " " ";" __device_support_sub "${device_support}")
      list(APPEND __device_support_max ${__device_support_sub})
      unset(__device_support_sub)
    endforeach()
    set(__supports)
    foreach(x ${supports})
      if(NOT x IN_LIST __device_support_max)
        if(${x})
          message(FATAL_ERROR "Device: ${ZWAY_CMAKE_ESP32_DEVICE} not support - ${x}")
        endif()
      else()
        list(APPEND __supports ${x})
      endif()
    endforeach()
    unset(__device_support_max)
    list(SORT __supports)
    set(supports ${__supports})
    unset(__supports)
    foreach(device_support ${__device_support})
      string(REPLACE " " ";" __device_support_sub "${device_support}")
      list(SORT __device_support_sub)
      if("${__device_support_sub}" STREQUAL "${supports}")
        set(__device_support)
        break()
      endif()
      unset(__device_support_sub)
    endforeach()

    foreach(device_support ${__device_support})
      string(REPLACE " " ";" __device_support_sub "${device_support}")
      list(SORT __device_support_sub)
      if("${__device_support_sub}" STREQUAL "${supports}")
        message(STATUS "__device_support_sub: ${__device_support_sub}")
        unset(__device_support)
        break()
      endif()
      unset(__device_support_sub)
    endforeach()
    if(__device_support)
      message(FATAL_ERROR "Device: ${ZWAY_CMAKE_ESP32_DEVICE} does not support this combination - ${supports}")
    endif()
  endif()
  if(NOT supports)
    message(FATAL_ERROR "At least one module must be activated.!!!")
  endif()

  set(subdirectorys "zcommons")
  if("z-way-srv-test" IN_LIST __zway_cmake_function_generate_option_PROJECTS)
    list(APPEND subdirectorys "zwaysrv")
  endif()
  if(cli)
    list(APPEND subdirectorys "zwaycli")
  endif()
  if(serialize)
    list(APPEND subdirectorys "zserializecommon")
  endif()
  if(zwave)
    if("ZWAY_CMAKE_SUPPORT_ZWAVE" IN_LIST supports)
      list(APPEND subdirectorys "zway")
      list(APPEND subdirectorys ${ZWAY_CMAKE_SECURITY_LIB})
      if(matter_bridge)
        if("ZWAY_CMAKE_SUPPORT_ZMATTER_BRIDGE" IN_LIST supports)
          list(APPEND subdirectorys "zmatterbridge")
          list(APPEND subdirectorys "zmatterbridgezway")
        endif()
      endif()
      if(serialize)
        list(APPEND subdirectorys "zserializezway")
      endif()
    endif()
  endif()
  if(zbee)
    if("ZWAY_CMAKE_SUPPORT_ZBEE" IN_LIST supports)
      list(APPEND subdirectorys "zbee")
      if(serialize)
        list(APPEND subdirectorys "zserializezbee")
      endif()
    endif()
  endif()
  list(REMOVE_DUPLICATES subdirectorys)

  set(ZWAY_CMAKE_SUPPORTS_MODULE
      "${supports}"
      CACHE STRING "" FORCE)
  set(ZWAY_CMAKE_SUPPORTS_SUBDIRECTORYS
      "${subdirectorys}"
      CACHE STRING "" FORCE)

  set(ZWAY_CMAKE_SAVE_PROJECTS
      "${__zway_cmake_function_generate_option_PROJECTS}"
      CACHE STRING "" FORCE)
  set(ZWAY_CMAKE_SAVE_SUPPORTS
      "${__zway_cmake_function_generate_option_SUPPORTS}"
      CACHE STRING "" FORCE)

  message(STATUS "ZWAY_CMAKE_SUPPORTS_MODULE: '${ZWAY_CMAKE_SUPPORTS_MODULE}'")
  message(STATUS "ZWAY_CMAKE_SUPPORTS_SUBDIRECTORYS: '${ZWAY_CMAKE_SUPPORTS_SUBDIRECTORYS}'")
  message(STATUS "ZWAY_CMAKE_SAVE_PROJECTS: '${ZWAY_CMAKE_SAVE_PROJECTS}'")
  message(STATUS "ZWAY_CMAKE_SAVE_SUPPORTS: '${ZWAY_CMAKE_SAVE_SUPPORTS}'")
endfunction()
