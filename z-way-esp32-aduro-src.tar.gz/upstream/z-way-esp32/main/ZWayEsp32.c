//
//  ZWayEsp32.c
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 16.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#include "ZWayEsp32Private.h"

#include "esp_mac.h"

ZWError _zway_esp32_get_hostname(ZwayEsp32Hostname_t *hostname)
{
    ZWBYTE mac[8];

    if (esp_efuse_mac_get_default(mac) != ESP_OK)
    {
        return InternalError;
    }
    if (snprintf(hostname->data, sizeof(hostname->data), "ZWAY-ESP-%02x%02x", mac[4], mac[5]) != 13)
    {
        return InvalidArg;
    }
    return NoError;
}