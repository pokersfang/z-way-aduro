//
//  ZwayEsp32WifiPrivate.h
//
//  Created by Alexander Polyakov on 03/07/25
//
//  Copyright (c) 2025 Trident IOT
//
//

#ifndef zway_esp32_ethernet_private_h
#define zway_esp32_ethernet_private_h

#if ZWAY_ESP32_WITH_ETHERNET
#include "ZPlatform.h"
#include "ZLogging.h"

#include "esp_eth.h"
#include "esp_mac.h"
#include "esp_netif_sntp.h"

#ifndef ZWAY_ETH_PHY_RST_GPIO
#define ZWAY_ETH_PHY_RST_GPIO 51
#endif
#ifndef ZWAY_ETH_MDC_GPIO
#define ZWAY_ETH_MDC_GPIO 31
#endif
#ifndef ZWAY_ETH_MDIO_GPIO
#define ZWAY_ETH_MDIO_GPIO 52
#endif
#ifndef ZWAY_ETHERNET_EMAC_TASK_STACK_SIZE
#define ZWAY_ETHERNET_EMAC_TASK_STACK_SIZE  2048
#endif
#ifndef ZWAY_ETH_SPI_HOST
#define ZWAY_ETH_SPI_HOST SPI2_HOST
#endif
#ifndef ZWAY_ETH_SPI_CLOCK_MHZ
#define ZWAY_ETH_SPI_CLOCK_MHZ 20
#endif
#ifndef ZWAY_ETH_SPI_SCLK_GPIO
#define ZWAY_ETH_SPI_SCLK_GPIO GPIO_NUM_13
#endif
#ifndef ZWAY_ETH_SPI_MOSI_GPIO
#define ZWAY_ETH_SPI_MOSI_GPIO GPIO_NUM_11
#endif
#ifndef ZWAY_ETH_SPI_MISO_GPIO
#define ZWAY_ETH_SPI_MISO_GPIO GPIO_NUM_12
#endif
#ifndef ZWAY_ETH_SPI_CS_GPIO
#define ZWAY_ETH_SPI_CS_GPIO GPIO_NUM_14
#endif
#ifndef ZWAY_ETH_SPI_INT_GPIO
#define ZWAY_ETH_SPI_INT_GPIO GPIO_NUM_10
#endif

typedef struct _ZWayEsp32EthCtx_s
{
    ZWLog logger;
    esp_netif_t *netif;
    esp_eth_handle_t eth_handle;
    esp_ip4_addr_t ip4_addr;
    SemaphoreHandle_t semph_wait_ip;
    esp_eth_mac_t *mac;
    esp_eth_phy_t *phy;
    esp_eth_netif_glue_handle_t eth_glue;
} _ZWayEsp32EthCtx_t;

void _zway_esp32_ethernet_shutdown(_ZWayEsp32EthCtx_t *ctx);
ZWError _zway_esp32_ethernet_connect(_ZWayEsp32EthCtx_t **ctx, ZWLog logger);
static inline ZWDWORD _zway_esp32_get_eth_ip4(_ZWayEsp32EthCtx_t *const ctx)
{
    return ctx->ip4_addr.addr;
}
#endif // ZWAY_ESP32_WITH_ETHERNET

#endif // zway_esp32_ethernet_private_h