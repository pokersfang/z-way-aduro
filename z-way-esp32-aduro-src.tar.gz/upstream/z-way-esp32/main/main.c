//
//  app.c
//
//  Ported by Alexander Polyakov on 10/10/24
//  from original z-way-test project
//  Created by Alex Skalozub on 1/6/12.
//
//  Copyright (c) 2012 Z-Wave.Me
//
//

#include <stdio.h>
#include <errno.h>

#include "ZSerialIO.h"
#include "ZFileOperations.h"
#include "ZSerializeDownloadPrivate.h"

#if ZWAY_SUPPORT_ZWAVE
#include "ZWayLib.h"
#include "ZLogging.h"
#include "ZWayCliPrivate.h"
#include "ZWayCliPrintPrivate.h"
#include "ZDefsPrivate.h"
#include "ZDefsPrivate.h"
#endif

#if ZWAY_SUPPORT_ZMATTER_BRIDGE
#include "ZMatterBridge.h"
#include "ZMatterBridgeLogging.h"
#include "ZMatterBridgeDevice.h"
#include "ZMatterBridgeZWay.h"
#endif // ZWAY_SUPPORT_ZMATTER_BRIDGE

#if ZWAY_ESP32_WITH_ETHERNET
#include "ZWayEsp32EthernetPrivate.h"
#endif // ZWAY_ESP32_WITH_ETHERNET

#if ZWAY_ESP32_WITH_WIFI
#include "ZWayEsp32WifiPrivate.h"
#endif // ZWAY_ESP32_WITH_WIFI

#include "ZWayEsp32Private.h"
#include "ZWayEsp32WebserverPrivate.h"

#include "esp_littlefs.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_vfs_dev.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#if CONFIG_ESP_CONSOLE_USB_SERIAL_JTAG
#include "driver/usb_serial_jtag.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#endif
#include "mdns.h"
#include "esp_netif_sntp.h"

#ifndef ZWAY_ESP32_DEFAULT_ZWAY_LOG_LEVEL
#define ZWAY_ESP32_DEFAULT_ZWAY_LOG_LEVEL Debug
#endif

#if ZWAY_ESP32_WITH_ETHERNET
static _ZWayEsp32EthCtx_t *__ctx_eth = NULL;
#endif // ZWAY_ESP32_WITH_ETHERNET

#if ZWAY_ESP32_WITH_WIFI
static _ZwayEsp32WifiCtx_t *__ctx_wifi = NULL;
#if defined(ZWAY_ESP32_RESCUE_BTN)
static ZWBOOL __force_wifi_ap = FALSE;
#endif
#endif // ZWAY_ESP32_WITH_WIFI

static _ZwayEsp32WebServerCtx_t __ctx_web_server;

#if defined(ZWAY_ESP32_XIAO_SHIELD_TEST_EXT)
static ZWError __init_xiao_test(void);
#endif

void _zway_esp32_set_status_led(const ZwayEsp32StatusLed_t status)
{
#if defined(ZWAY_ESP32_LED_RED) && defined(ZWAY_ESP32_LED_GREEN) && defined(ZWAY_ESP32_LED_BLUE)
    uint32_t red = 0;
    uint32_t green = 0;
    uint32_t blue = 0;

    switch (status)
    {
        case ZwayEsp32StatusLedRescue:
            red = 1;
            break;
        case ZwayEsp32StatusLedEthernetDown:
            blue = 1;
            break;
        case ZwayEsp32StatusLedEthernetUp:
            green = 1;
            break;
        case ZwayEsp32StatusLedOff:
        default:
            break;
    }

    (void)gpio_set_level(ZWAY_ESP32_LED_RED, red);
    (void)gpio_set_level(ZWAY_ESP32_LED_GREEN, green);
    (void)gpio_set_level(ZWAY_ESP32_LED_BLUE, blue);
#else
    (void)status;
#endif
}

static ZWCSTR __add_help(void)
{
    return (
        "w [SSID PASSWD] Setups WiFi credentials.\n"
#if defined(ZWAY_ESP32_RESCUE_BTN)
        "b Check buttons state\n"
#endif
#if defined(ZWAY_ESP32_XIAO_SHIELD_TEST_EXT)
        "T Starts Xiao board hardware test\n"
#endif 
        "I Prints IP-address information.\n"
        "F Prints LittleFS total/used.\n");
}

#if defined(ZWAY_ESP32_XIAO_SHIELD_TEST_EXT)
static void __add_parse_T(void)
{
    (void)__init_xiao_test();
    int i;
    for (i = 0; i < 20; i++)
    {
        gpio_set_level(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA, i & 0x01);
        gpio_set_level(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL, i & 0x02);
        usleep(100000UL);
    } 
    gpio_set_level(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA, 0);
    gpio_set_level(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL, 0);
}
#endif

#if ZWAY_ESP32_WITH_WIFI
static void __add_parse_w(ZWCSTR cmd_buffer)
{
    int nconv;
    _ZwayEsp32WifiCredentials_t cred;
    ZWCHAR cmd;
    
    nconv = sscanf(cmd_buffer, "%c %s %s", &cmd, cred.info.ssid, cred.info.psw);
    if (nconv == 1)
    {
        if (_zway_esp32_load_wifi_credentials(ZWAY_ESP32_WIFI_CREDENTIAL_FILENAME, &cred) == NoError)
        {
            (void)printf("\nCurrent WIFI credentials: %s %s\n\n", cred.info.ssid, cred.info.psw);
        }
        else
        {
            (void)printf("\nThere are no WIFI credentials!\n\n");
        }
    }
    else if (nconv == 3)
    {
        if (_zway_esp32_save_wifi_credentials(ZWAY_ESP32_WIFI_CREDENTIAL_FILENAME, &cred) == NoError)
        {
            (void)printf("\nSave WIFI credentials DONE!\n\n");
        }
        else
        {
            (void)printf("\nSave WIFI credentials FAIL!\n\n");
        }
    }
    else
    {
        (void)printf("Syntax error!\n");
    }
}
#endif // ZWAY_ESP32_WITH_WIFI

static void __add_parse_I(void)
{
    ZwayEsp32Hostname_t hostname;
    ZWDWORD ip4 = 0;
    int i;

#if ZWAY_ESP32_WITH_ETHERNET
    if (__ctx_eth != NULL)
    {
        ip4 = _zway_esp32_get_eth_ip4(__ctx_eth);
    }
#endif // ZWAY_ESP32_WITH_ETHERNET
#if ZWAY_ESP32_WITH_WIFI
    if (ip4 == 0 && __ctx_wifi != NULL)
    {
        ip4 = _zway_esp32_get_wifi_ip4(__ctx_wifi);
    }
#endif // ZWAY_ESP32_WITH_WIFI

    (void)printf("Device IP address: ");
    if (ip4 != 0)
    {
        for (i = 0; i < 4; i++, ip4 >>= 8)
        {
            (void)printf("%d", ip4 & 0xFF);
            if (i != 3)
            {
                (void)printf(".");
            }
        }
    }
    else
    {
        (void)printf("Unknown");
    }
    (void)printf("\n");
    if (_zway_esp32_get_hostname(&hostname) != NoError)
    {
        (void)printf("Device hostname: Unknown\n");
        return;
    }
    (void)printf("Device hostname: %s\nBrowser: http://%s.local:%d\n", hostname.data, hostname.data, ZWAY_ESP_WEB_SERVER_PORT);
#if ZWAY_ESP32_WITH_WIFI
    (void)printf("SoftAP SSID: %s\nSoftAP password: %s\n", hostname.data, ZWAY_ESP32_DEFAULT_AP_WIFI_PASS);
#endif // ZWAY_ESP32_WITH_WIFI
}

static ZWBOOL __add_parse(ZWCSTR cmd_buffer)
{
    ZWCHAR cmd;
    int nconv;
    
    nconv = sscanf(cmd_buffer, "%c", &cmd);
    if (nconv <= 0)
    {
        return FALSE;
    }

    switch (cmd)
    {
#if defined(ZWAY_ESP32_RESCUE_BTN)
        case 'b':
            printf("BTN state:%d\n", gpio_get_level(ZWAY_ESP32_RESCUE_BTN));
            break;
#endif
#if ZWAY_ESP32_WITH_WIFI
        case 'w':
            __add_parse_w(cmd_buffer);
            break;
#endif // ZWAY_ESP32_WITH_WIFI
        #if defined(ZWAY_ESP32_XIAO_SHIELD_TEST_EXT)
        case 'T':
            __add_parse_T();
            break;
        #endif
        case 'I':
            __add_parse_I();
            break;
        case 'F':
            {
                size_t total;
                size_t used;
                if (esp_littlefs_info(NULL, &total, &used) == ESP_OK)
                {
                    (void)printf("LittleFS size total: %zd bytes, used: %zd bytes\n", total, used);
                }
            }
            break;
        default:
            return FALSE;
    }
    return TRUE;
}

static ZWError __init_tcp_ip_stack(void)
{
    if (esp_netif_init() != ESP_OK)
    {
        return InternalError;
    }
    if (esp_event_loop_create_default() != ESP_OK)
    {
        return InternalError;
    }
    return NoError;
}
#if defined(ZWAY_ESP32_XIAO_SHIELD_TEST_EXT)
static void IRAM_ATTR __xiao_button_isr_handler(void *arg)
{
    static uint8_t __xiao_test_pins[2] = {5, 6};
    static uint8_t __xiao_test_levels[2];
    int index = (int)arg;
    __xiao_test_levels[index] = 1 - __xiao_test_levels[index];
    gpio_set_level(__xiao_test_pins[index], __xiao_test_levels[index]);
}
static ZWError __init_xiao_test(void)
{
    // The second button 
    #ifdef XIOA_SHIELD_BTN2
    if (gpio_reset_pin(XIOA_SHIELD_BTN2) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_direction(XIOA_SHIELD_BTN2, GPIO_MODE_INPUT) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_pull_mode(XIOA_SHIELD_BTN2, GPIO_PULLUP_ONLY) != ESP_OK)
    {
        return InternalError;
    }
    #endif
    #if defined(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA) && defined(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL)
    // QWIIC connnector for tests
    if (gpio_reset_pin(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_direction(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA, GPIO_MODE_OUTPUT) != ESP_OK)
    {
        return InternalError;
    }
    gpio_set_level(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA, 0);
    if (gpio_reset_pin(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_direction(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL, GPIO_MODE_OUTPUT) != ESP_OK)
    {
        return InternalError;
    }
    gpio_set_level(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL, 0);
    #endif // defined(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SDA) && defined(ZWAY_ESP32_XIOA_SHIELD_QWIIC_SCL)
    #ifdef XIOA_SHIELD_BTN2
    gpio_set_intr_type(XIOA_SHIELD_BTN2, GPIO_INTR_POSEDGE);
    gpio_install_isr_service(XIOA_SHIELD_BTN2);
    gpio_isr_handler_add(XIOA_SHIELD_BTN2, __xiao_button_isr_handler, (void *)0);
    #endif
    #ifdef ZWAY_ESP32_RESCUE_BTN
    gpio_set_intr_type(ZWAY_ESP32_RESCUE_BTN, GPIO_INTR_POSEDGE);
    gpio_install_isr_service(ZWAY_ESP32_RESCUE_BTN);
    gpio_isr_handler_add(ZWAY_ESP32_RESCUE_BTN, __xiao_button_isr_handler, (void *)1);
    #endif
    return NoError;
}
#endif // ZWAY_ESP32_XIAO_SHIELD_TEST_EXT

static ZWError __init_gpio(void)
{
#if defined(ZWAY_ESP32_LED_RED) && defined(ZWAY_ESP32_LED_GREEN) && defined(ZWAY_ESP32_LED_BLUE)
    static const gpio_num_t led_pins[] = {
        ZWAY_ESP32_LED_RED,
        ZWAY_ESP32_LED_GREEN,
        ZWAY_ESP32_LED_BLUE,
    };
    static const uint32_t led_levels[] = {
        0,
        0,
        0,
    };

    for (size_t i = 0; i < sizeof(led_pins) / sizeof(led_pins[0]); i++)
    {
        if (gpio_reset_pin(led_pins[i]) != ESP_OK)
        {
            return InternalError;
        }
        if (gpio_set_level(led_pins[i], led_levels[i]) != ESP_OK)
        {
            return InternalError;
        }
        if (gpio_set_direction(led_pins[i], GPIO_MODE_OUTPUT) != ESP_OK)
        {
            return InternalError;
        }
    }
#endif

#if defined(ZWAY_ESP32_RESCUE_BTN)
    // Set Rescue Button pin mode
    if (gpio_reset_pin(ZWAY_ESP32_RESCUE_BTN) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_direction(ZWAY_ESP32_RESCUE_BTN, GPIO_MODE_INPUT) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_pull_mode(ZWAY_ESP32_RESCUE_BTN, GPIO_PULLUP_ONLY) != ESP_OK)
    {
        return InternalError;
    }
#if ZWAY_ESP32_WITH_WIFI
    const int rescue_button_level = gpio_get_level(ZWAY_ESP32_RESCUE_BTN);
    __force_wifi_ap = (rescue_button_level == 0) ? TRUE : FALSE;
    ESP_LOGI(ZWAY_ESP32_LOG_SOURCE, "Rescue button GPIO%d level=%d, force_ap=%d",
        ZWAY_ESP32_RESCUE_BTN, rescue_button_level, __force_wifi_ap);
#endif
#endif
#if defined(ZWAY_ESP32_LED_RED) && defined(ZWAY_ESP32_LED_GREEN) && defined(ZWAY_ESP32_LED_BLUE)
#if ZWAY_ESP32_WITH_WIFI && defined(ZWAY_ESP32_RESCUE_BTN)
    _zway_esp32_set_status_led(__force_wifi_ap ? ZwayEsp32StatusLedRescue : ZwayEsp32StatusLedEthernetDown);
#else
    _zway_esp32_set_status_led(ZwayEsp32StatusLedEthernetDown);
#endif
#endif
#if defined(ZWAY_ESP32_RST_PIN)
    if (gpio_reset_pin(ZWAY_ESP32_RST_PIN) != ESP_OK)
    {
        return InternalError;
    }
    if (gpio_set_direction(ZWAY_ESP32_RST_PIN, GPIO_MODE_OUTPUT) != ESP_OK)
    {
        return InternalError;
    }
    gpio_set_level(ZWAY_ESP32_RST_PIN, 1);
    usleep(5000UL);
    gpio_set_level(ZWAY_ESP32_RST_PIN, 0);
    usleep(50000UL);
    gpio_set_level(ZWAY_ESP32_RST_PIN, 1);
#endif

    return NoError;
}

static ZWError __init_nvs(void)
{
    esp_err_t vret;

    vret = nvs_flash_init();
    if (vret == ESP_ERR_NVS_NO_FREE_PAGES || vret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        if (nvs_flash_erase() != ESP_OK)
        {
            return InternalError;
        }
        if (nvs_flash_init() != ESP_OK)
        {
            return InternalError;
        }
    }
    return NoError;
}

#if !ZWAY_SUPPORT_ZMATTER_BRIDGE
static ZWError __init_mdns_service(void)
{
    if (mdns_init() != ESP_OK)
    {
        return InternalError;
    }
    
    ZwayEsp32Hostname_t hostname;
    const ZWError err = _zway_esp32_get_hostname(&hostname);
    if (err != NoError)
    {
        return err;
    }
    // set hostname
    if (mdns_hostname_set(hostname.data) != ESP_OK)
    {
        return InternalError;
    }
    // set default instance
    if (mdns_instance_name_set("Z-Way controller based on ESP32 chip") != ESP_OK)
    {
        return InternalError;
    }
    // add our services
    if (mdns_service_add(NULL, "_http", "_tcp", ZWAY_ESP_WEB_SERVER_PORT, NULL, 0) != ESP_OK)
    {
        return InternalError;
    }
    // NOTE: services must be added before their properties can be set
    // use custom instance for the web server
    if (mdns_service_instance_name_set("_http", "_tcp", hostname.data) != ESP_OK)
    {
        return InternalError;
    }
    return NoError;
}
#endif // !ZWAY_SUPPORT_ZMATTER_BRIDGE

#if ZWAY_ESP32_WITH_ETHERNET
static ZWError __init_ethernet(const ZWLog logger)
{
    return _zway_esp32_ethernet_connect(&__ctx_eth, logger);
}
#endif // ZWAY_ESP32_WITH_ETHERNET

#if ZWAY_ESP32_WITH_WIFI
static ZWError __init_wifi(const ZWLog logger)
{
    ZWBOOL force_ap = FALSE;
    
#if defined(ZWAY_ESP32_RESCUE_BTN)
    // Preserve the boot-time sample, while also accepting a button held later.
    force_ap = (__force_wifi_ap || gpio_get_level(ZWAY_ESP32_RESCUE_BTN) == 0) ? TRUE : FALSE;
    __force_wifi_ap = force_ap;
#endif
    
    // If there is no wifi credentials we have an error and switch to softap mode
    if (_zway_esp32_wifi_connect(&__ctx_wifi, logger, ZWAY_ESP32_LOG_SOURCE, force_ap) == NoError)
    {
        return NoError;
    }
    zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Warning, "Unable to connect to WiFi - switching to soft app mode.");
    return _zway_esp32_wifi_connect(&__ctx_wifi, logger, ZWAY_ESP32_LOG_SOURCE, TRUE);
}
#endif // ZWAY_ESP32_WITH_WIFI

static ZWError __init_ntp(const ZWLog logger)
{
    static const esp_sntp_config_t config = ESP_NETIF_SNTP_DEFAULT_CONFIG("pool.ntp.org");
    
    if (esp_netif_sntp_init(&config) != ESP_OK)
    {
        return InternalError;
    }
    
    zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Information, "Wait Sync time using NTP...");
    if (esp_netif_sntp_sync_wait(pdMS_TO_TICKS(10000)) != ESP_OK)
    {
        return BadData;
    }
    return NoError;
}

// We don't close or cancel anything because we'll reboot to esp anyway
static ZWError __app_proc(const ZWLog logger)
{
    ZWError err = __init_gpio();
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init gpio", err);
        return err;
    }
    
#if ZWAY_SUPPORT_ZWAVE
    ZWay zway = NULL;
    err = zway_init(&zway, zio_port_settings_generate(ZWAY_DEFAULT_COM_PORT_FOR_CONTROLER, 1, ZWAY_ESP32_ZWAVE_UART1_TX, ZWAY_ESP32_ZWAVE_UART1_RX, 768), 0, NULL, NULL, NULL, NULL, logger);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init ZWay", err);
        return err;
    }
    err = zway_device_add_callback(zway, DeviceAdded | DeviceRemoved | InstanceAdded | InstanceRemoved | CommandAdded | CommandRemoved, _zway_cli_print_d_i_cc_event, NULL);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init callback for zway", err);
        return err;
    }
#endif // ZWAY_SUPPORT_ZWAVE
    
    zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Information, "Init NVS...");
    err = __init_nvs();
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init nvs", err);
        return err;
    }
    
    zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Information, "Init IP Stack...");
    err = __init_tcp_ip_stack();
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init TCP/IP stack", err);
        return err;
    }
    
#if ZWAY_ESP32_WITH_ETHERNET
#if ZWAY_ESP32_WITH_WIFI && defined(ZWAY_ESP32_RESCUE_BTN)
    if (!__force_wifi_ap)
#endif
    {
        zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Information, "Init ethernet...");
        err = __init_ethernet(logger);
        if (err != NoError)
        {
            ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init ethernet", err);
            return err;
        }
    }
#endif
    
#if ZWAY_ESP32_WITH_WIFI
    zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Information, "Init WIFI...");
    if ((err = __init_wifi(logger)) != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init wifi", err);
        return err;
    }
#endif // ZWAY_ESP32_WITH_WIFI
    
    // Sync time using NTP
#if ZWAY_ESP32_WITH_WIFI && defined(ZWAY_ESP32_RESCUE_BTN)
    if (!__force_wifi_ap)
#endif
    {
        zlog_write(logger, ZWAY_ESP32_LOG_SOURCE, Information, "Init NTP..");
        if ((err = __init_ntp(logger)) != NoError)
        {
            ZWAY_ESP32_LOG_ERR(logger, Information, "Failed Sync time using NTP", err);
        }
    }
    
#if ZWAY_SUPPORT_ZWAVE
    err = zway_start(zway, _zway_cli_print_zway_terminated, NULL);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to start ZWay", err);
        return err;
    }
    err = zway_discover(zway);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to negotiate with Z-Wave stick", err);
        return err;
    }
#endif
    
#if !ZWAY_SUPPORT_ZMATTER_BRIDGE
    if ((err = __init_mdns_service()) != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init mdns service", err);
        return err;
    }
#endif // !ZWAY_SUPPORT_ZMATTER_BRIDGE
    
    // Start WebServer
    err = _zway_esp32_web_server_start(&__ctx_web_server, zway);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init web server", err);
        return err;
    }
    
#if ZWAY_SUPPORT_ZMATTER_BRIDGE
    ZMatterBridge_t matter_bridge;
    err = zmatter_bridge_init(&matter_bridge, NULL, "matter_bridge", logger);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to init ZMatterBridge", err);
        return err;
    }
    
    err = zmatter_bridge_start(matter_bridge);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to start ZMatterBridge", err);
        return err;
    }
    
#if ZWAY_SUPPORT_ZWAVE
    err = zmatter_bridge_zway_add_callback(zway, matter_bridge);
    if (err != NoError)
    {
        ZWAY_ESP32_LOG_ERR(logger, Critical, "Failed to add callback ZMatterBridge for zway", err);
        return err;
    }
#endif // ZWAY_SUPPORT_ZWAVE
#endif // ZWAY_SUPPORT_ZMATTER_BRIDGE
    
    // Starts the CLI interface. USB Serial/JTAG returns from reads when no USB
    // host is attached. Keep the application alive in that case and resume the
    // CLI after a host is connected instead of tearing everything down/rebooting.
#if CONFIG_ESP_CONSOLE_USB_SERIAL_JTAG
    for (;;)
    {
        while (!usb_serial_jtag_is_connected())
        {
            vTaskDelay(pdMS_TO_TICKS(250));
        }

        clearerr(stdin);
        err = _zway_cli_process(zway, __add_help(), __add_parse);
        if (usb_serial_jtag_is_connected())
        {
            break;
        }

        clearerr(stdin);
    }
#else
    err = _zway_cli_process(zway, __add_help(), __add_parse);
#endif
    
#if ZWAY_SUPPORT_ZMATTER_BRIDGE
#if ZWAY_SUPPORT_ZWAVE
    (void)zmatter_bridge_zway_remove_callback(zway, matter_bridge);
#endif // ZWAY_SUPPORT_ZWAVE
    
    (void)zmatter_bridge_stop(matter_bridge);
#endif // ZWAY_SUPPORT_ZMATTER_BRIDGE
    
    (void)_zway_esp32_web_server_stop(&__ctx_web_server);
    
#if ZWAY_SUPPORT_ZWAVE
    (void)zway_stop(zway);
    
    zway_terminate(&zway);
#endif // ZWAY_SUPPORT_ZWAVE
    
    zlog_close(logger);
    
    return err;
}

static ZWError __app_main(void)
{
    ZWError err = zfile_fs_init("storage", "dynamic");
    if (err != NoError)
    {
        ESP_LOGE(ZWAY_ESP32_LOG_SOURCE, "Failed to init file system: %d", err);
        return err;
    }
    
    const ZWLog logger = zlog_create(stdout, ZWAY_ESP32_DEFAULT_ZWAY_LOG_LEVEL);
    if (logger == NULL)
    {
        ESP_LOGI(ZWAY_ESP32_LOG_SOURCE, "unable to create log!\n");
        return AccessDenied;
    }
    
    err = __app_proc(logger);
    if (err != NoError)
    {
        zlog_error(logger, ZWAY_ESP32_LOG_SOURCE, Debug, "Finished working with status", err);
    }
    ESP_LOGI(ZWAY_ESP32_LOG_SOURCE, "__app_proc was exited!\n");
    return err;
}

void app_main(void)
{
    if (__app_main() != NoError)
    {
        ESP_LOGI(ZWAY_ESP32_LOG_SOURCE, "main thread 15 sec for restart");
        sleep(15);
    }
    esp_restart();
}
