//
//  ZWayEsp32Private.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 16.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_esp32_private_h
#define zway_esp32_private_h

#include "ZPlatform.h"

#define ZWAY_ESP32_LOG_SOURCE "esp"

#if ZWAY_ESP32_DEBUG
#define ZWAY_ESP32_LOG_ERR(LOGGER, LEVEL, STR, ERR) zlog_error(LOGGER, ZWAY_ESP32_LOG_SOURCE, LEVEL, STR, ERR);
#else
#define ZWAY_ESP32_LOG_ERR(LOGGER, LEVEL, STR, ERR)
#endif // ZWAY_ESP32_DEBUG

typedef struct ZwayEsp32Hostname_s
{
    ZWCHAR data[16];
} ZwayEsp32Hostname_t;

ZWError _zway_esp32_get_hostname(ZwayEsp32Hostname_t *hostname);

#endif // zway_esp32_private_h
