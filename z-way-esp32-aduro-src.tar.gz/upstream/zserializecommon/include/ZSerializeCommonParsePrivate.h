//
//  ZSerializeCommonParsePrivate.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 08.10.2024.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_common_parse_private_h
#define zserialize_common_parse_private_h

#include "ZPlatform.h"
#include "ZLog.h"
#include "ZArchivePrivate.h"
#include "ZSerializeCommonPrivate.h"
#include "ZSerializeCommonRunPrivate.h"

#include <regex.h>

#define ZSERIALIZE_COMMON_PARSE_NULL "null"
#define ZSERIALIZE_COMMON_PARSE_ZWAVE_API "ZWaveAPI"
#define ZSERIALIZE_COMMON_PARSE_FIRMWARE_UPDATE "FirmwareUpdate"

#define ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_0 ""
#define ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_3 "()()()"
#define ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_4 "()()()()"
#define ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_5 "()()()()()"
#define ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_6 "()()()()()()"

#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_ID "\\[([0-9]+)\\]"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CC(prefix_cc) "(" prefix_cc ZSERIALIZE_COMMON_PARSE_REG_PREFIX_ID "|([A-Za-z0-9_]+))"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX(prefix, dongle) "^/((" ZSERIALIZE_COMMON_PARSE_ZWAVE_API ")|(" prefix "\\." dongle "))/"

#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CONTROLLER "controller"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICES "devices"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICES ZSERIALIZE_COMMON_PARSE_REG_PREFIX_ID
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CONTROLLER_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CONTROLLER "\\." ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_6
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICES_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICES "\\." ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_6
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE(instances) instances ZSERIALIZE_COMMON_PARSE_REG_PREFIX_ID
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_OPTIONAL(instances) "(\\." ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE(instances) ")?"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_MANDATORY(instances) "(" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE(instances) ")"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE "\\." ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_5

#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_FUNCTION "([A-Za-z0-9_]+)\\((.*)\\)"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_SET "data([^ ]+)? *= *(.*)"
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_GET "data([^ ]+)? *"

#define ZSERIALIZE_COMMON_PARSE_REG_CONTROLLER_FUNCTION "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CONTROLLER_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_FUNCTION "$"
#define ZSERIALIZE_COMMON_PARSE_REG_CONTROLLER_DATA_SET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CONTROLLER_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_SET "$"
#define ZSERIALIZE_COMMON_PARSE_REG_CONTROLLER_DATA_GET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CONTROLLER_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_GET "$"

#define ZSERIALIZE_COMMON_PARSE_REG_DEVICE_FUNCTION "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_FUNCTION "$"
#define ZSERIALIZE_COMMON_PARSE_REG_DEVICE_DATA_SET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_SET "$"
#define ZSERIALIZE_COMMON_PARSE_REG_DEVICE_DATA_GET "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DATA_GET "$"

#define ZSERIALIZE_COMMON_PARSE_REG_DEVICES_FUNCTION "^" ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICES_PATH ZSERIALIZE_COMMON_PARSE_REG_PREFIX_FUNCTION "$"

#define ZSERIALIZE_COMMON_PARSE_DONGLE_REQUEST(prefix) "/" prefix "/list"
#define ZSERIALIZE_COMMON_PARSE_DONGLE_RESPONSE(dongle) "[\"" dongle "\"]"

#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_PATH(instances) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE "\\." ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_MANDATORY(instances) "\\." ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_3
#define ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CC_PATH(instances, prefix_cc) ZSERIALIZE_COMMON_PARSE_REG_PREFIX_DEVICE ZSERIALIZE_COMMON_PARSE_REG_PREFIX_INSTANCE_OPTIONAL(instances) "\\." ZSERIALIZE_COMMON_PARSE_REG_PREFIX_CC(prefix_cc) "\\." ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_0

#define ZSERIALIZE_COMMON_PARSE_REG_DATA(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_PREFIX(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_4 "Data/([0-9]+)$"
#define ZSERIALIZE_COMMON_PARSE_REG_RUN(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_PREFIX(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_4 "Run/(.+)$"
#define ZSERIALIZE_COMMON_PARSE_REG_INSPECT_QUEUE(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_PREFIX(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_4 "InspectQueue$"
#define ZSERIALIZE_COMMON_PARSE_REG_FIRMWARE_UPDATE(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_PREFIX(prefix, dongle) ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_4 ZSERIALIZE_COMMON_PARSE_FIRMWARE_UPDATE "/([0-9]+)$"

#define ZSERIALIZE_COMMON_PARSE_REG_ZWAY_FUNCTION ZSERIALIZE_COMMON_PARSE_REG_EMPTY_GROUPS_6 ZSERIALIZE_COMMON_PARSE_REG_PREFIX_FUNCTION "$"

static inline ZWBOOL _zserialize_common_parse_command_contains(ZWCSTR input, ZWCSTR cmd, size_t length)
{
    if (strncmp(input, cmd, length) != 0)
    {
        return FALSE;
    }
    return TRUE;
}

typedef regmatch_t _ZSerializeCommonParseCommandReg_t[9];

typedef struct _ZSerializeCommonParseCommandObjectHandler_s
{
    ZWCSTR match_reg_cc_function;
    ZWCSTR match_reg_cc_data_set;
    ZWCSTR match_reg_instance_data_set;
    ZWCSTR match_reg_cc_data_get;
    ZWCSTR match_reg_instance_data_get;
    
    ZWError (* function_ctrl)(_zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *);
    const _ZSerializeCommonRunTableContainer_t *container_ctrl;
    
    ZWError (*function_with_return)(_zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *, _ZSerializeCommonCtx_t *);
    const _ZSerializeCommonRunTableContainer_t *container_with_return;
    
    ZWError (*function_dev)(const _zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *, _ZSerializeCommonDeviceId_t);
    const _ZSerializeCommonRunTableContainer_t *container_dev;
    
    ZWError (*function_devs)(_zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *);
    const _ZSerializeCommonRunTableContainer_t *container_devs;
    
    ZWError (*function_fc)(_zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *);
    const _ZSerializeCommonRunTableContainer_t *container_fc;
    
    ZWError (*function_cc)(_zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *, _ZSerializeCommonDeviceId_t, _ZSerializeCommonInstanceId_t);
    const _ZSerializeCommonRunTableContainer_t *container_cc;
    
    ZWError (*function_cc_common)(_zhash_murmur_t, ZWCSTR, _ZParseArgumentsContainer_t *, _ZSerializeCommonRootObject *, _ZSerializeCommonDeviceId_t, _ZSerializeCommonInstanceId_t, _ZSerializeCommonCCId_t);
    const _ZSerializeCommonRunTableContainer_t *container_cc_common;
} _ZSerializeCommonParseCommandObjectHandler_t;

typedef struct _ZSerializeCommonParseObjectHandler_s
{
    ZWCSTR pattern_data;
    ZWCSTR pattern_inspect_queue;
    ZWError (*inspect_queue)(_ZSerializeCommonCtx_t *);
    ZWCSTR pattern_parse_command;
    ZWCSTR dongle_request;
    ZWCSTR dongle_response;
    
    const _ZSerializeCommonRootObjectHandler_t *root_object_handler;
    
    const _ZSerializeCommonParseCommandObjectHandler_t *parse_object_handler;
} _ZSerializeCommonParseObjectHandler_t;

typedef struct _ZSerializeCommonParseExtractPathResult_s
{
    ZWCSTR path;
    ZWBOOL with_value;
    ZWBOOL with_type;
    ZWDataType dh_type:8;
    _ZParseArgumentsType_t parse_type:8;
} _ZSerializeCommonParseExtractPathResult_t;

ZWEXPORT_PRIVATE ZWBOOL _zserialize_common_parse_normalize_path(ZWSTR path);
ZWEXPORT_PRIVATE ZWError _zserialize_common_parse_command(_ZSerializeCommonCtx_t *const serialize, const _ZSerializeCommonParseCommandObjectHandler_t *const parse_object_handler, const ZWSTR input);
ZWEXPORT_PRIVATE ZWError _zserialize_common_parse(_ZSerializeCommonRootObject *const root_object, const _ZSerializeCommonParseObjectHandler_t *const parse_object_handler, const ZWSTR command, const _ZStreamHttpWrite_t *const stream, void *const ctx_stream, const ZWBOOL gzip);
ZWEXPORT_PRIVATE ZWBOOL _zserialize_common_parse_match(const ZWSTR input, const ZWCSTR pattern, _ZSerializeCommonParseCommandReg_t m);
static inline ZWCSTR _zserialize_common_parse_reg_extract_path_device_id(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    return &input[m[1].rm_so];
}

static inline ZWCSTR _zserialize_common_parse_reg_extract_path_instance_id(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    const regoff_t rm_so = m[3].rm_so;
    if (rm_so == -1)
    {
        return NULL;
    }
    return &input[rm_so];
}

static inline ZWCSTR _zserialize_common_parse_reg_extract_path_class_id(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    const regoff_t rm_so = m[5].rm_so;
    if (rm_so == -1)
    {
        return NULL;
    }
    return &input[rm_so];
}

static inline ZWCSTR _zserialize_common_parse_reg_extract_path_class_name(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    const regoff_t rm_so = m[6].rm_so;
    if (rm_so == -1)
    {
        return NULL;
    }
    return &input[rm_so];
}

static inline ZWSTR _zserialize_common_parse_reg_extract_command_path_unsafe(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    const regoff_t rm_so = m[7].rm_so;
    if (rm_so == -1)
    {
        return NULL;
    }
    return &input[m[7].rm_so];
}

static inline ZWCSTR _zserialize_common_parse_reg_extract_command_path(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    const ZWSTR result = _zserialize_common_parse_reg_extract_command_path_unsafe(m, input);
    if (result == NULL)
    {
        return "";
    }
    return result;
}

static inline ZWSTR _zserialize_common_parse_reg_extract_path_arg(const _ZSerializeCommonParseCommandReg_t m, const ZWSTR input)
{
    const regoff_t rm_so = m[8].rm_so;
    if (rm_so == -1)
    {
        return NULL;
    }
    return &input[rm_so];
}

ZWEXPORT_PRIVATE ZWError _zserialize_common_parse_reg_extract_path_dh_arg(_ZSerializeCommonParseCommandReg_t m, const ZWSTR input, _ZSerializeCommonParseExtractPathResult_t *const result);

#endif // zserialize_common_parse_private_h
