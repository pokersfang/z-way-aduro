//
//  ZSerializeCommonPrivate.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 08.10.2024.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_common_private_h
#define zserialize_common_private_h

#include "ZPlatform.h"
#include "ZData.h"
#include "ZByteOperations.h"
#include "ZStreamPrivate.h"

#include <float.h>

typedef void _ZSerializeCommonRootObject;
typedef ZWWORD _ZSerializeCommonDeviceId_t;
typedef ZWBYTE _ZSerializeCommonInstanceId_t;
typedef ZWWORD _ZSerializeCommonCCId_t;

typedef struct _ZSerializeCommonCCIdResult_s
{
    void *ctx;
    ZWCSTR name;
    ZDataHolder data;
    _ZSerializeCommonCCId_t cc_id;
} _ZSerializeCommonCCIdResult_t;

typedef struct _ZSerializeCommonInstanceIdResult_s
{
    time_t commands_update_time;
    void *ctx;
    void *instance;
    ZDataHolder data;
    _ZSerializeCommonInstanceId_t instance_id;
} _ZSerializeCommonInstanceIdResult_t;

typedef struct _ZSerializeCommonDeviceIdResult_s
{
    time_t instances_update_time;
    void *ctx;
    void *device;
    ZDataHolder data;
    _ZSerializeCommonDeviceId_t device_id;
} _ZSerializeCommonDeviceIdResult_t;

typedef struct _ZSerializeCommonSettings_s
{
    ZWError (*write)(void *args, void *data, size_t length);
    void *args;
    size_t json_block_size;
} _ZSerializeCommonSettings_t;

typedef struct _ZSerializeCommonRootObjectHandler_s
{
    ZWCSTR name_instances;
    ZWCSTR name_command_classes;
    ZDataHolder (*find_controller_data)(const _ZSerializeCommonRootObject *root_object, ZWCSTR path);
    ZWBOOL (*command_classes_get_iterator)(const _ZSerializeCommonInstanceIdResult_t *, _ZSerializeCommonCCIdResult_t *);
    ZWBOOL (*command_classes_next_iterator)(_ZSerializeCommonCCIdResult_t *);
    ZWBOOL (*instances_get_iterator)(const _ZSerializeCommonDeviceIdResult_t *, _ZSerializeCommonInstanceIdResult_t *);
    ZWBOOL (*instances_next_iterator)(const _ZSerializeCommonDeviceIdResult_t *, _ZSerializeCommonInstanceIdResult_t *);
    ZWBOOL (*devices_get_iterator)(_ZSerializeCommonRootObject *, _ZSerializeCommonDeviceIdResult_t *, time_t *);
    ZWBOOL (*devices_next_iterator)(_ZSerializeCommonDeviceIdResult_t *);
} _ZSerializeCommonRootObjectHandler_t;

typedef struct _ZSerializeCommonCtx_s
{
    _ZSerializeCommonRootObject *root_object;
    const _ZSerializeCommonRootObjectHandler_t *root_object_handler;
    const _ZStreamWriter_t *writer;
    void *ctx_writer;
    _ZSerializeCommonDeviceIdResult_t result_device_id;
    _ZSerializeCommonInstanceIdResult_t result_instance_id;
    _ZSerializeCommonCCIdResult_t result_cc_id;
    ZWCHAR buffer_for_printf[MAX(Z_SIZE_MEMORY_FOR_PRINTF_NUMBER(ZWDWORD64), (FLT_MAX_10_EXP + 6 + 1 + 1 + 1 + 1) * sizeof(ZWCHAR))]; // 6 - fractional; 1 - zero; 1 - point; 1 + sign; 1 - one significant number
    ZWBOOL empty;
} _ZSerializeCommonCtx_t;

static inline _ZSerializeCommonRootObject *_zserialize_common_get_root_object(_ZSerializeCommonCtx_t *ctx)
{
    return ctx->root_object;
}

static inline const _ZSerializeCommonRootObjectHandler_t *_zserialize_common_get_root_object_handler(_ZSerializeCommonCtx_t *ctx)
{
    return ctx->root_object_handler;
}

static inline void _zserialize_common_init(_ZSerializeCommonCtx_t *const ctx, _ZSerializeCommonRootObject *root_object, const _ZSerializeCommonRootObjectHandler_t *const root_object_handler, const _ZStreamWriter_t *const writer, void *const ctx_writer)
{
    ctx->root_object = root_object;
    ctx->root_object_handler = root_object_handler;
    ctx->writer = writer;
    ctx->ctx_writer = ctx_writer;
    ctx->empty = TRUE;
}

static inline void _zserialize_common_free(_ZSerializeCommonCtx_t *const UNUSED(ctx))
{
}

static inline ZWBOOL _zserialize_common_is_empty(_ZSerializeCommonCtx_t *const ctx)
{
    return ctx->empty;
}

ZWEXPORT_PRIVATE ZWError _zserialize_common_tree(_ZSerializeCommonCtx_t *const ctx, const time_t timestamp);
ZWEXPORT_PRIVATE ZWError _zserialize_common_stub(_ZSerializeCommonCtx_t *const ctx, const ZWCSTR str);
static inline ZWError _zserialize_common_boolean(_ZSerializeCommonCtx_t *const ctx, const ZWBOOL value)
{
    return _zserialize_common_stub(ctx, value ? "true" : "false");
}

ZWEXPORT_PRIVATE ZWError _zserialize_common_dh(_ZSerializeCommonCtx_t *const ctx, const ZDataHolder data);
ZWEXPORT_PRIVATE ZWError _zserialize_common_dh_value(_ZSerializeCommonCtx_t *const ctx, const ZDataHolder data);
ZWEXPORT_PRIVATE ZWError _zserialize_common_string(_ZSerializeCommonCtx_t *const ctx, const ZWCSTR str, const size_t length);
ZWEXPORT_PRIVATE ZWError _zserialize_common_string_escape(_ZSerializeCommonCtx_t *const ctx, const ZWCSTR str);
ZWEXPORT_PRIVATE ZWError _zserialize_common_float(_ZSerializeCommonCtx_t *const ctx, const float n);
ZWEXPORT_PRIVATE ZWError _zserialize_common_int(_ZSerializeCommonCtx_t *const ctx, const int n);
ZWEXPORT_PRIVATE ZWError _zserialize_common_ptr(_ZSerializeCommonCtx_t *const ctx, const void *const ptr);

ZWEXPORT_PRIVATE ZWError _zserialize_common_parse_to_string(_ZSerializeCommonRootObject *const root_object, const _ZSerializeCommonRootObjectHandler_t *const root_object_handler, const ZWBOOL is_string, _ZByteData_t *const data, void *const arg, ZWError(*const callback)(_ZSerializeCommonCtx_t *, void *));

#endif // zserialize_common_private_h
