//
//  ZSerializeCommonQueuePrivate.c
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 16.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_common_queue_private_h
#define zserialize_common_queue_private_h

#include "ZSerializeCommonPrivate.h"

#define ZSERIALIZE_COMMON_QUEUE_COMMA(CTX) \
    err = _zserialize_common_queue_comma(CTX); \
    if (err != NoError) \
    { \
        return err; \
    }

#define ZSERIALIZE_COMMON_QUEUE_PTR(CTX, PTR) \
    err = _zserialize_common_ptr(CTX, PTR); \
    if (err != NoError) \
    { \
        return err; \
    }

#define ZSERIALIZE_COMMON_QUEUE_INT(CTX, N) \
    err = _zserialize_common_int(CTX, N); \
    if (err != NoError) \
    { \
        return err; \
    }

#define ZSERIALIZE_COMMON_QUEUE_INT_COMMA(CTX, N) \
    err = _zserialize_common_queue_int_comma(CTX, N); \
    if (err != NoError) \
    { \
        return err; \
    }

#define ZSERIALIZE_COMMON_QUEUE_ARRAY_OPEN(CTX) \
    err = _zserialize_common_queue_array_open(CTX); \
    if (err != NoError) \
    { \
        return err; \
    }

#define ZSERIALIZE_COMMON_QUEUE_ARRAY_CLOSE(CTX) \
    err = _zserialize_common_queue_array_close(CTX); \
    if (err != NoError) \
    { \
        return err; \
    }

ZWEXPORT_PRIVATE ZWError _zserialize_common_queue_array_open(_ZSerializeCommonCtx_t *const serialize);
ZWEXPORT_PRIVATE ZWError _zserialize_common_queue_array_close(_ZSerializeCommonCtx_t *const serialize);
ZWEXPORT_PRIVATE ZWError _zserialize_common_queue_comma(_ZSerializeCommonCtx_t *const serialize);
ZWEXPORT_PRIVATE ZWError _zserialize_common_queue_int_comma(_ZSerializeCommonCtx_t *const serialize, const int n);
ZWEXPORT_PRIVATE ZWError _zserialize_common_queue_string_escape(_ZSerializeCommonCtx_t *const serialize, const ZWCSTR str);

#endif // zserialize_common_queue_private_h
