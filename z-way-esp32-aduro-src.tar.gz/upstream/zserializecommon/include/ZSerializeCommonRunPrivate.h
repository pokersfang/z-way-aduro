//
//  ZSerializeCommonRunPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_common_run_private_h
#define zserialize_common_run_private_h

#include "ZParseArgumentsPrivate.h"
#include "ZLogPrivate.h"
#include "ZByteOperationsPrivate.h"

#define ZRERIALIZE_COMMON_RUN_MAX_ARGS 20 // API calls generator will fail if these constants are too low
#define ZRERIALIZE_COMMON_CC_MAX_LENGTH_HASH 43 // API calls generator will fail if these constants are too low

typedef struct _ZSerializeCommonRunTable_s
{
    const void *function;
#if !defined(__ZWAY_CLI_DESCRIPTION_DISABLE__)
    ZWCSTR description;
#endif
    const _zparse_arguments_type_t *type;
    const _ZParseArgumentsValue_t *def;
    ZWDWORD hash;
    ZWBYTE length_type;
    ZWBYTE length_def;
} _ZSerializeCommonRunTable_t;

typedef struct _ZSerializeCommonRunTableContainer_s
{
    size_t n;
    _ZSerializeCommonRunTable_t table[];
} _ZSerializeCommonRunTableContainer_t;

typedef struct _ZSerializeCommonRunCtx_s
{
    ZWLog log;
    const _ZSerializeCommonRunTable_t *table;
    _ZParseArgumentsResult_t arguments;
    _ZParseArgumentsContainer_t container[ZRERIALIZE_COMMON_RUN_MAX_ARGS];
    size_t count_arg_start;
    size_t count_arg_end;
} _ZSerializeCommonRunCtx_t;

ZWEXPORT_PRIVATE _zhash_murmur_t _zhash_murmur_calcul(const void *const command, const size_t length);
ZWEXPORT_PRIVATE ZWError _zserialize_common_run_init(_ZSerializeCommonRunCtx_t *const ctx, const ZWLog log, const void *const command, const size_t length, const _ZSerializeCommonRunTableContainer_t *const table_container);
ZWEXPORT_PRIVATE ZWError _zserialize_common_run_hash_init(_ZSerializeCommonRunCtx_t *const ctx, const ZWLog log, const _zhash_murmur_t hash, const _ZSerializeCommonRunTableContainer_t *const table_container);
ZWEXPORT_PRIVATE ZWError _zserialize_common_run_init_arguments_start(_ZSerializeCommonRunCtx_t *const ctx, void **const ptr, const size_t count);
ZWEXPORT_PRIVATE ZWError _zserialize_common_run_init_arguments_end(_ZSerializeCommonRunCtx_t *const ctx, void **const ptr, const size_t count);
ZWEXPORT_PRIVATE ZWError _zserialize_common_run(_ZSerializeCommonRunCtx_t *const ctx, ZWCSTR params);
ZWEXPORT_PRIVATE ZWError _zserialize_common_run_custom(const ZWLog log, ZWCSTR params, _ZParseArgumentsContainer_t *const container, _zparse_arguments_type_t const *type, const ZWBYTE length_type, const _ZParseArgumentsValue_t *const def, const ZWBYTE length_def);

#endif // zserialize_common_run_private_h
